<?php
/**
 * Created by PhpStorm.
 * User: king-pc
 * Date: 5/11/2019
 * Time: 4:33 PM
 */


header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Methods: POST,GET,OPTIONS");
header("Access-Control-Allow-Headers: content-type");
header("Access-Control-Allow-Headers: NCZ");
header('Content-type: application/json;charset=utf-8');
require_once ('wp-config.php');
class test
{

    public $wpdb;
    public $NumberOfRecords=0;
    public $Offset=0;

    function __construct(){
        global $wpdb;
        $this->wpdb = $wpdb;
        if(isset($_GET['NumberOfRecords']) && isset($_GET['NumberOfOffset'])){
            if($_GET['NumberOfRecords']!=0){
                $this->NumberOfRecords=$_GET['NumberOfRecords'];
                $this->Offset=$_GET['NumberOfOffset'];
            }else{
                $this->NumberOfRecords=10;
            }
        }else{
            $this->  $NumberOfRecords=10;
        }
    }


    public $jason;
    public  function  test(){
        global $wpdb;
        $this->wpdb = $wpdb;
        if(isset($_GET['PNo'])){
            printf("<b>has no</b>");
        }else{
            $data=$this->wpdb->get_results(  "SELECT p.*, pm2.meta_value, substr(p.post_content,1,350) as post_content1 FROM `63_posts` AS p INNER JOIN `63_postmeta` AS pm1 ON p.id = pm1.post_id INNER JOIN `63_postmeta` AS pm2 ON pm1.meta_value = pm2.post_id WHERE(p.post_status='Publish' AND p.post_type ='post' AND pm2.meta_key = '_wp_attached_file' AND pm1.meta_key = '_thumbnail_id') ORDER BY p.post_date DESC LIMIT {$this->NumberOfRecords} OFFSET {$this->Offset}
");
            echo  json_encode($data);

            //echo json_encode("hello");
        }
    }
}


if($_SERVER['REQUEST_METHOD']=="GET"){
    /* here i want to filter each callable functions from outside */
    switch($_GET['f']) {
        case 'allPo':
            specificFunction();


    }
    $object = new test();
    $object->test();
}

